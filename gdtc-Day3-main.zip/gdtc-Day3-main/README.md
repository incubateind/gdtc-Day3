# Github Developer Tech Camp

**GitHub developer tech camp** (GDTC) aims to cultivate and inspire future leaders by accommodating a platform to share ideas and create a space for innovation where ideas come to life. GDTC is a platform where the innovators and industry experts meet from diverse fields like Edutech, Healthtech, and Fintech. The event provides a platform for collaboration, discussion, and connecting 50+ colleges & students across India who were a part of the Code Innovation Series to ignite their passion to curb India’s growth story.


## DAY 3

We would be having a session on DEVOPS today <https://www.youtube.com/watch?v=bp6XJC92bMA> at 5:30 PM.

#### WE will be hosting our personal portfolios on GitHub pages like this <https://rexyagami.github.io/my-portfolio/>, so that at the end of the Tech Camp we have our own portfolios on the internet.

### Step 1
#### FORK this repo

### Step 2
#### Today we will work on customizing the portfolios, u are free to apply ur design sense.


### Step 3
#### You can again ping @rexyagami and me(@kroy96) for help with ur portfolios. Once done go to Settings of ur forked Repo and then scroll down and enable Github pages.



####  Voila!! You now have ur own personal portfolio at [username].github.io/[repoName] 

Lets utilize Version Controlling and Collaborative Development to its fullest!!!!     



### THIS IS WHAT PRATIK(@rexyagami) HAS MADE <https://rexyagami.github.io/my-portfolio/>





![](https://storage.googleapis.com/incind/Day-3PSpmjL2)

